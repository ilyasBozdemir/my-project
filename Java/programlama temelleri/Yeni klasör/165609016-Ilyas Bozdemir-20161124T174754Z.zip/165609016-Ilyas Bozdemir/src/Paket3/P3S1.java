package Paket3;
public class P3S1 {
    public static void main(String[] args) {
   System.out.println("Merhaba");     
    
     
    }
    

}

