package Paket5;
public class P5S1 {
public static void main(String[] args) {
    System.out.println("Merhaba");    
    
     
    }
    

}

