
package Paket1;

public class P1S1 {
    public static void main(String[] args) {
        
      System.out.println("Merhaba");
     
    }
    

}
