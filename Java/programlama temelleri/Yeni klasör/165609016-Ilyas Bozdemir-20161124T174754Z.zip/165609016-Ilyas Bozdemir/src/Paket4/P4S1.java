package Paket4;
public class P4S1 {
public static void main(String[] args) {
   System.out.println("Merhaba");     
    
     
    }
    

}

