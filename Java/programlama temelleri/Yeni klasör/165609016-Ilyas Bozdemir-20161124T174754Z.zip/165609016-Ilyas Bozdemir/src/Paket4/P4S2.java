package Paket4;
import java.util.Scanner;
public class P4S2 {
public static void main(String[] args) {
        
    Scanner bilgi = new Scanner (System.in) ;
  System.out.println("Metni Girin");
  String metin = bilgi.nextLine();
  System.out.println(metin);
  
     
    }
    

}
