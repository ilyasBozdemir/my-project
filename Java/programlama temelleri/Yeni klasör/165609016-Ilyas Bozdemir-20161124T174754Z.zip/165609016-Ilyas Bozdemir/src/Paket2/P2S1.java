package Paket2;
public class P2S1 {
public static void main(String[] args) {
    System.out.println("Merhaba");    
    
     
    }
    

}

